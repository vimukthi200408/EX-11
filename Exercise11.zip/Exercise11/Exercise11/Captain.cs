﻿using System;
namespace Exercise11
{
    public class Captain
    {     

        private int age;
        private string name;
        private int yearsOfExperience;
        private int registryNumber;

        public Captain(int age,string name, int yearsOfExperience, int registryNumber)
        {
            this.age = age;
            this.name = name;
            this.yearsOfExperience = yearsOfExperience;
            this.registryNumber = registryNumber;
        }
        public string getName()
        {
            return name;
        }
        public int getyearsOfExperience()
        {
            return yearsOfExperience;
        }

        public Boolean equals(Captain captain)
        {
            Boolean equals = false;
            if ((this.name == captain.name) && (this.registryNumber == captain.registryNumber))
            {
                equals = true;
            }
           
            return equals;
        }
        public string toString()
        {
            return name+", age: "+age+"\nYOE: "+yearsOfExperience+"\nRegistry: "+registryNumber;
        }



    }
}

