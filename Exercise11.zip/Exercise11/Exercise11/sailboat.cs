﻿using System;
namespace Exercise11
{
    public class sailboat
    {
        private int size;
        private string name;
        private string model;
        private Captain captain;


        public sailboat(int size, string name, string model)
        {
            this.size = size;
            this.name = name;
            this.model = model;
        }

        public Boolean assignCaptain(Captain captain)
        {
            Boolean assign = false;
            
            if (this.captain is null){

                this.captain = captain;
                assign = true;
            }
            else if (captain.getyearsOfExperience() > this.captain.getyearsOfExperience())
            {
                this.captain = captain;
                assign = true;
            }
            
            return assign;
        }
        public Captain getCaptain()
        {
            return captain;
        }

        public Boolean equals(sailboat sb)
        {
            if ((this.name == sb.name) && (this.captain == sb.captain))
            {
                return true;
            }
            return false;
        }
        public string toString()
        {
            if (this.captain is null)
            {

                return "Relativity is a " + size + " feet " + model + " " + name + " with no captain.";
            }
            else
            {
                return "Relativity is a " + size + " feet " + model + " " + name + "; Her captain is: " + captain.getName();

            }

        }

    }
}

