﻿namespace Exercise11
{
    class SailboatRunner
    {
        static void Main(String[] args)
        {
           
            sailboat sb = new sailboat(12,"Ship","medel222");
            Console.WriteLine(sb.toString());
            Captain captain = new Captain(77, "Vimukthi", 14, 30);
            sb.assignCaptain(captain);
            Console.WriteLine(sb.toString());
            Console.ReadKey();

           
        }
    }
}